import { NextRequest, NextResponse } from "next/server";
import path from "path";
import { readFile, stat } from "fs/promises";
import { getStorageConfig, FileStorageService } from "@/lib/file-upload";

export async function GET(
  request: NextRequest,
  { params }: { params: { filename: string } }
) {
  try {
    const filename = params.filename;
    
    // Basic security: validate filename
    if (!filename || filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      return new NextResponse("Invalid filename", { status: 400 });
    }

    const config = getStorageConfig();
    
    if (config.type === 'local' && config.local) {
      // Check if it's a thumbnail request
      const isThumb = request.nextUrl.searchParams.get('thumb') === 'true';
      const filePath = isThumb 
        ? path.join(config.local.uploadPath, 'thumbs', filename)
        : path.join(config.local.uploadPath, filename);

      try {
        // Check if file exists and get stats
        const stats = await stat(filePath);
        if (!stats.isFile()) {
          return new NextResponse("File not found", { status: 404 });
        }

        // Read file
        const fileBuffer = await readFile(filePath);
        
        // Determine MIME type based on extension
        const ext = path.extname(filename).toLowerCase();
        const mimeTypes: Record<string, string> = {
          '.jpg': 'image/jpeg',
          '.jpeg': 'image/jpeg',
          '.png': 'image/png',
          '.webp': 'image/webp',
        };
        
        const mimeType = mimeTypes[ext] || 'application/octet-stream';

        // Set appropriate headers
        const headers = new Headers();
        headers.set('Content-Type', mimeType);
        headers.set('Content-Length', stats.size.toString());
        headers.set('Cache-Control', 'public, max-age=31536000, immutable'); // 1 year cache
        headers.set('Content-Disposition', `inline; filename="${filename}"`);

        return new NextResponse(fileBuffer, {
          status: 200,
          headers,
        });

      } catch (error) {
        console.error('Error serving file:', error);
        return new NextResponse("File not found", { status: 404 });
      }
    } 
    
    if (config.type === 'minio' && config.minio) {
      // For MinIO, generate a signed URL and redirect
      const storageService = new FileStorageService(config);
      const isThumb = request.nextUrl.searchParams.get('thumb') === 'true';
      const key = isThumb ? `thumbs/${filename}` : `images/${filename}`;
      
      try {
        const signedUrl = await storageService.getSignedUrl(key, 3600); // 1 hour expiry
        return NextResponse.redirect(signedUrl);
      } catch (error) {
        console.error('Error generating signed URL:', error);
        return new NextResponse("File not found", { status: 404 });
      }
    }

    return new NextResponse("Storage not configured", { status: 500 });

  } catch (error) {
    console.error('File serving error:', error);
    return new NextResponse("Internal server error", { status: 500 });
  }
}

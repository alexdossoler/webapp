import { NextRequest, NextResponse } from "next/server";
import { v4 as uuidv4 } from "uuid";
import { prisma, calculateLeadScore } from "@/lib/prisma";
import { 
  processFileUploads, 
  FileStorageService, 
  getStorageConfig 
} from "@/lib/file-upload";

// Types for the incoming form data
interface IntakeFormData {
  goal: string;
  deadline: string;
  isDeadlineFlexible: string;
  features: string;
  otherRequirements: string;
  budgetMin: string;
  budgetMax: string;
  budgetTier: string;
  contactName: string;
  contactEmail: string;
  contactPhone: string;
  preferredContact: string;
  additionalNotes: string;
  addOns: string;
  source: string;
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();

    // Extract form fields
    const data: IntakeFormData = {
      goal: formData.get("goal") as string,
      deadline: formData.get("deadline") as string,
      isDeadlineFlexible: formData.get("isDeadlineFlexible") as string,
      features: formData.get("features") as string,
      otherRequirements: formData.get("otherRequirements") as string,
      budgetMin: formData.get("budgetMin") as string,
      budgetMax: formData.get("budgetMax") as string,
      budgetTier: formData.get("budgetTier") as string,
      contactName: formData.get("contactName") as string,
      contactEmail: formData.get("contactEmail") as string,
      contactPhone: formData.get("contactPhone") as string,
      preferredContact: formData.get("preferredContact") as string,
      additionalNotes: formData.get("additionalNotes") as string,
      addOns: formData.get("addOns") as string,
      source: formData.get("source") as string,
    };

    // Basic validation
    if (!data.goal || !data.deadline || !data.contactEmail) {
      return NextResponse.json(
        { success: false, message: "Missing required fields: goal, deadline, or email" },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.contactEmail)) {
      return NextResponse.json(
        { success: false, message: "Invalid email format" },
        { status: 400 }
      );
    }

    // Validate deadline is not in the past
    const deadlineDate = new Date(data.deadline);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (deadlineDate < today) {
      return NextResponse.json(
        { success: false, message: "Deadline cannot be in the past" },
        { status: 400 }
      );
    }

    // Process files if any
    const files = formData.getAll("files") as File[];
    let processedFiles: any[] = [];
    let attachmentPaths: string[] = [];

    if (files.length > 0) {
      const storageConfig = getStorageConfig();
      const storageService = new FileStorageService(storageConfig);
      
      const fileBuffers = await Promise.all(
        files.map(async (file) => ({
          buffer: Buffer.from(await file.arrayBuffer()),
          originalName: file.name
        }))
      );

      const { success, errors } = await processFileUploads(fileBuffers, storageService);
      
      if (errors.length > 0) {
        console.warn("File upload errors:", errors);
      }
      
      processedFiles = success;
      attachmentPaths = success.map(f => f.filename);
    }

    // Parse JSON fields
    const parsedFeatures = JSON.parse(data.features || "[]");
    const parsedAddOns = JSON.parse(data.addOns || "[]");

    // Generate submission ID
    const submissionId = uuidv4();

    // Get client metadata
    const ipAddress = request.headers.get("x-forwarded-for") || 
                     request.headers.get("x-real-ip") || 
                     "unknown";
    const userAgent = request.headers.get("user-agent") || "unknown";

    // Create database transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create intake submission record (audit trail)
      const submission = await tx.intakeSubmission.create({
        data: {
          id: submissionId,
          goal: data.goal,
          deadline: data.deadline,
          isDeadlineFlexible: data.isDeadlineFlexible === "true",
          features: parsedFeatures,
          otherRequirements: data.otherRequirements || "",
          budgetMin: parseInt(data.budgetMin) || 0,
          budgetMax: parseInt(data.budgetMax) || 0,
          budgetTier: data.budgetTier || "",
          contactName: data.contactName || "",
          contactEmail: data.contactEmail,
          contactPhone: data.contactPhone || "",
          preferredContact: data.preferredContact || "email",
          additionalNotes: data.additionalNotes || "",
          addOns: parsedAddOns,
          attachments: processedFiles,
          source: data.source || "direct",
          ipAddress,
          userAgent,
        },
      });

      // Create lead record
      const leadData = {
        submissionId,
        name: data.contactName || "Unknown",
        email: data.contactEmail,
        phone: data.contactPhone || null,
        preferredContact: data.preferredContact as any || "email",
        goal: data.goal,
        deadline: deadlineDate,
        isDeadlineFlexible: data.isDeadlineFlexible === "true",
        features: parsedFeatures,
        otherRequirements: data.otherRequirements || null,
        budgetMin: parseInt(data.budgetMin) || 0,
        budgetMax: parseInt(data.budgetMax) || 0,
        budgetTier: data.budgetTier || null,
        additionalNotes: data.additionalNotes || null,
        addOns: parsedAddOns,
        attachments: attachmentPaths,
        source: data.source || "direct",
        ipAddress,
        userAgent,
      };

      // Calculate lead score
      const leadScore = calculateLeadScore({
        budgetMax: leadData.budgetMax,
        deadline: leadData.deadline,
        features: leadData.features,
        addOns: leadData.addOns,
        additionalNotes: leadData.additionalNotes,
        attachments: leadData.attachments,
      });

      const lead = await tx.lead.create({
        data: {
          ...leadData,
          leadScore,
        },
      });

      // Mark submission as processed
      await tx.intakeSubmission.update({
        where: { id: submissionId },
        data: { 
          processed: true,
          leadId: lead.id 
        },
      });

      return { submission, lead };
    });

    console.log("New intake submission processed:", {
      submissionId,
      leadId: result.lead.id,
      leadScore: result.lead.leadScore,
      email: data.contactEmail
    });

    // TODO: Add integrations here:
    // - Send acknowledgment email to client
    // - Send notification to team (Slack/Discord)
    // - Trigger n8n webhook
    // - Create CRM record

    return NextResponse.json({
      success: true,
      message: "Project request submitted successfully",
      submissionId,
      leadId: result.lead.id,
    });

  } catch (error) {
    console.error("Project intake submission error:", error);
    return NextResponse.json(
      { 
        success: false, 
        message: "Internal server error. Please try again later." 
      },
      { status: 500 }
    );
  }
}

// Handle other HTTP methods
export async function GET() {
  return NextResponse.json(
    { message: "Method not allowed. Use POST to submit intake forms." },
    { status: 405 }
  );
}
